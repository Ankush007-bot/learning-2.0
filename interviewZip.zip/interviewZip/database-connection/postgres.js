

var {Client} = require('pg')

var client = new Client ({
    user: 'postgres',
    password: 'user123#',
    host: 'localhost',
    port: 5432,
    database: 'postgres',
    
})


client.connect()

client.query(`select * from table_demo`,(error,result)=>{
    if (!error) {
        console.log(result.rows)
    }
    client.end()
})