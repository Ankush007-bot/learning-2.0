// Basic MongoDB Questions
// What is MongoDB?

// How is MongoDB different from relational databases?

// What is a document in MongoDB?

// What is a collection in MongoDB?

// Explain BSON. How is it different from JSON?

// What are the advantages of using MongoDB?
MongoDB offers several advantages that make it a strong choice for modern applications:

Flexible Schema – It’s schema-less, so we can store documents with varying structures, which is great for agile development and evolving requirements.

Document-Oriented – Data is stored in JSON-like BSON format, which maps naturally to objects in code, making it developer-friendly.

High Performance – It provides fast read/write operations, especially with support for indexes and in-memory storage.
– It supports rich queries and a robust aggregation framework for advanced data processing.


// How do you create a database in MongoDB?
mongoose.connect('mongodb://localhost:27017/myDatabase')
This connects to (and creates if needed) the myDatabase database.

Then you can define schemas and interact with collections.


// How to insert a document into a MongoDB collection?

const { MongoClient } = require('mongodb');

async function run() {
  const uri = 'mongodb://localhost:27017';
  const client = new MongoClient(uri);

  try {
    await client.connect();
    const db = client.db('myDatabase');
    const collection = db.collection('users');

    const result = await collection.insertMany([     //insertOne
      { name: 'Bob', age: 28 },
      { name: 'Charlie', age: 35 },
      { name: 'Diana', age: 22 }
    ]);

    console.log('Inserted IDs:', result.insertedIds);
  } finally {
    await client.close();
  }
}

run();



// How do you update a document in MongoDB?

// How do you delete documents from a collection?

// What is a primary key in MongoDB?

// Explain the role of _id in MongoDB.

// How do you query documents in MongoDB?

// What is a replica set?

// What is sharding in MongoDB?

// 🟡 Intermediate MongoDB Questions
// Explain indexing in MongoDB and why it is important.

// What types of indexes does MongoDB support?

// How do you create an index?

// What is aggregation in MongoDB?

// Explain the aggregation pipeline.

// How do you perform joins in MongoDB?

// What are embedded documents and references?

// How does MongoDB handle transactions?

// Explain the difference between updateOne(), updateMany(), and replaceOne().

// What is a capped collection?

// How do you perform text search in MongoDB?

// What is the purpose of the explain() method?

// How do you handle schema design in MongoDB?

// What is the WiredTiger storage engine?

// How does MongoDB handle concurrency?