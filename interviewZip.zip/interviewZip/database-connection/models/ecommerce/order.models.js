import mongoose from "mongoose";

const orderSchema = new mongoose.Schema({

                           orderPrice:{
                            type:Number,
                            required:true
                           },
                           customer:{
                            type:mongoose.Schema.Types.ObjectId,
                            ref:"User"
                           },
                           orderItems:{
                            types:[orderItemSchema]  // it will require a mini model orderItemSchema
                           },
                           address:{
                            type:String,
                            required:true
                           },
                           status:{
                            type:String,
                            enum:["PENDING","CANCELLED","DELIVERED"],  // enum means choices
                            default:"PENDING"
                           }
                           },{timestamps:true})

const orderItemSchema= new mongoose.Schema({
     productId:{   // we are only saving ID so that we can find the product later by the help of ID
      type: mongoose.Schema.Types.ObjectId,
      ref:"Product"
     },
     quantity:{
        type:Number,
        required:true
     }
})

export const Order = mongoose.model("Order",orderSchema)