// import mongoose from "mongoose";

const mongoose = require('mongoose')

const projectSchema = new mongoose.Schema({
   
    projectName:{
        type:String,
        required:true,
       
    },
    teamLeaderName:{
        type:String,
        required:true,
       
    },
    managerName:{
        type:String,
        required:true,
       
    },
    
    
    })
    



    // import mongoose from "mongoose";



const schema2 = new mongoose.Schema({
   
    tranee:{
        type:String,
        required:true,
       
    },
    teamLeaderName:{
        type:String,
        required:false,
       
    },
    managerName:{
        type:String,
        required:false,
       
    },
    
    
    })
    

//All collection will save in mongoose


var teamMember = mongoose.models.schema2 || mongoose.model('teamMember', schema2)
//Project is collection name

var Project=mongoose.models.projectSchema || mongoose.model('Project', projectSchema)

module.exports = {teamMember,Project}