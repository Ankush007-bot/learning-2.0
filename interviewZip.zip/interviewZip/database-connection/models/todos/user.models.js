import { lowerCase } from "lodash";
import mongoose from "mongoose";


const userSchema = new mongoose.Schema(
    {
        username:{
           type:String,
           required:true,
           unique:true,
           lowerCase:true
           },
    email:String,
    password:{
        type:String,
        required:[true,"password is required"],   // required field accepts array for various actions

    },
    isActive:Boolean
    },

    {timestamps:true} // it will add createdAt and updatedAt the object is pass as a second object
)

export const User=mongoose.model("User",userSchema)  // make a schema User on the basis of userSchema
                                                      // final collection name will be users