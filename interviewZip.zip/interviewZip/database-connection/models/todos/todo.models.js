import mongoose, { model } from "mongoose";


const todoSchema =new mongoose.Schema(
    {
        content:{
            type:String,
            required:true,
        },
        complete:{
            type:Boolean,
            default:false   //default value
        },
        createdBy:{
             type:mongoose.Schema.Types.ObjectId ,  //it is a special type beacaus we will give userSchema reference here
             ref:"User"  // name inside the model in userSchema
            }  ,         // as soon as mongoos see this type of 'type' then it automatically knows that we will give him reference to some other schema
            subTodos:[
                {
                    type:mongoose.Schema.Types.ObjectId,
                    ref:"SubTodo"
                }
            ] /// array of sub-Todos
   },{timestamps:true}
)

export const Todo = mongoose.model('Todo',todoSchema)