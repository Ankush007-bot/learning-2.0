

var path = require('path');
var express = require('express');
var bodyParser = require('body-parser');
const app = express();
var bodyParser = require('body-parser');
bodyParser = require('body-parser');
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true, limit: '10mb' }));

var cors = require('cors');
var fs = require('fs');
var bearerToken = require('express-bearer-token');




app.use('/database',require('./controller/routes'))

const port = process.env.PORT || 5000;  // if port is available in process.env then run the file other wise run on 5000
                                         // but in prod if port is not available in process.env then app will not run


app.listen(port,()=>{
    console.log('server is on')
})



