
const express = require('express');

const router = express.Router();
const app = express();
// bodyParser = require('body-parser');
// app.use(bodyParser.json());
// app.use(bodyParser.urlencoded({ extended: true, limit: '10mb' }));
const dbConnect = require('../config/dbConnect')

const {Project} =  require('../models/schemas') //when we import from multiple objects then use curly bracket

router.route('/createProjectDetails').post(async (req, res) => {

    dbConnect;
    console.log(Project,'project')
    const project = await Project.create(req.body);
    return res.json("projectDetails updated")
})


router.route('/getProjectDetails').post( async (req, res) => {

    dbConnect;

const projectDetails =  await Project.find({ "projectName": req.body.projectName });
   console.log(projectDetails)

    return res.json(projectDetails)

})


module.exports = router;
