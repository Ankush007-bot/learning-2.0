

//first install mongo db



const mongoose =require('mongoose')
const dbConnect = ()=>{
    if(mongoose.connection.readyState>=1){
        return
    }
// this file is written in next.config.js file
  //  mongoose.connect('mongodb://localhost:27017/edelweissKT', {useNewUrlParser: true, useUnifiedTopology: true}).then(con => console.log("connected to database")).catch(err=>console.log(err))

mongoose.connect('mongodb://127.0.0.1:27017/edelweissKT').then(con => console.log(`connected to database --->${con.connection.host}` )).catch(err=>console.log(err));

}


 exports.module= dbConnect();



