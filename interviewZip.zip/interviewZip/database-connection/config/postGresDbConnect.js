
const {client} = require('pg')

const client = new client ({
    user: 'Ankush',
    password: 'abc123',
    host: 'localhost',
    port: 5432,
    database: 'Edelweiss_KT',

})

client.connect()

client.query(`select * from users`,(error,result)=>{
    if (!error) {
        console.log(result.rows)
    }
    client.end()
})



///

// Relational databas: These are the databases in which data is stores inside the Table
// SQL : Structured query Language


// 1. Database Operations
// sql
// Copy
// Edit
// CREATE DATABASE dbName;  -- Create a new database
// CREATE DATABASE IF NOT EXISTS dbName;  -- Create a new database

//SHOW DATABASES
//SHOW TABLES

// USE dbName;              -- Select a database
// DROP DATABASE dbName;    -- Delete a database

// 2. Table Operations
// sql
// Copy
// Edit
// CREATE TABLE users (
//     id INT PRIMARY KEY AUTO_INCREMENT,
//     name VARCHAR(100),
//     email VARCHAR(100) UNIQUE,
//     age INT
// );  -- Create a table


//PRIMARY KEY ---> It always not null, always unique

// DROP TABLE users;  -- Delete a table

// ALTER TABLE users ADD COLUMN address VARCHAR(255);  -- Add a new column

// ALTER TABLE users MODIFY COLUMN age SMALLINT;  -- Modify column type


// 3. Insert Data
// sql
// Copy
// Edit
// INSERT INTO users (name, email, age) VALUES ('Alice', 'alice@example.com', 25);
// also INSERT INTO users VALUES ('Alice', 'alice@example.com', 25);


// 4. Read Data (SELECT Queries)
// sql
// Copy
// Edit
// SELECT * FROM users;  -- Select all rows
// SELECT name, email FROM users WHERE age > 20;  -- Filtered selection
// SELECT COUNT(*) FROM users;  -- Count total rows
// SELECT DISTINCT age FROM users;  -- Get unique ages


// 5. Update Data
// sql
// Copy
// Edit
// UPDATE users SET age = 30 WHERE name = 'Alice';


// 6. Delete Data
// sql
// Copy
// Edit
// DELETE FROM users WHERE age < 18;  -- Delete underage users


// 7. Sorting & Limiting Results
// sql
// Copy
// Edit
// SELECT * FROM users ORDER BY age DESC LIMIT 5;  -- Get 5 oldest users


// 8. Joins (Combining Tables)
// sql
// Copy
// Edit
// SELECT users.name, orders.amount
// FROM users
// JOIN orders ON users.id = orders.user_id;  -- Inner Join


// 9. Grouping & Aggregation
// sql
// Copy
// Edit
// SELECT age, COUNT(*) FROM users GROUP BY age;  -- Count users per age group
// SELECT age, AVG(age) FROM users GROUP BY age;  -- Average age per group


// 10. Indexes & Performance Optimization
// sql
// Copy
// Edit
// CREATE INDEX idx_users_email ON users(email);  -- Create an index for faster searches








// Here are the most commonly used data types in SQL:

// 1. String Data Types
// VARCHAR(n) – Variable-length string (e.g., VARCHAR(255))  it will only occupy the neccessary space in memory
// CHAR(n) – Fixed-length string (e.g., CHAR(10))  it will reserve the memory equal to its length so it is inefficient process
// TEXT – Large text storage
// BLOB – Binary large object (for images, files, etc.)
// 2. Numeric Data Types
// INT – Integer (whole number)
// SMALLINT – Smaller integer range
// BIGINT – Large integer range
// DECIMAL(p, s) – Exact decimal values (e.g., DECIMAL(10,2))
// FLOAT – Approximate floating-point number
// DOUBLE – Higher precision floating-point number
// 3. Date & Time Data Types
// DATE – Stores only date (YYYY-MM-DD)
// TIME – Stores only time (HH:MM:SS)
// DATETIME – Stores both date & time
// TIMESTAMP – Stores date & time with automatic updates
// 4. Boolean Data Type
// BOOLEAN – Stores TRUE or FALSE (Internally stored as 1 or 0)
// 5. Other Data Types
// JSON – Stores JSON-formatted data
// UUID – Stores universally unique identifiers
// ENUM – Stores one value from a predefined list
// SET – Stores multiple values from a predefined list



// In SQL, keys are used to uniquely identify records in a table and establish relationships between tables. There are different types of keys:

// 1. Primary Key
// A unique identifier for each record in a table.
// Cannot contain NULL values.
// Example:
// sql
// Copy
// Edit
// CREATE TABLE Employees (
//     EmployeeID INT PRIMARY KEY,
//     Name VARCHAR(100)
// );
// 2. Foreign Key
// Establishes a relationship between two tables.
// Refers to the Primary Key of another table.
// Ensures referential integrity.
// Example:
// sql
// Copy
// Edit
// CREATE TABLE Orders (
//     OrderID INT PRIMARY KEY,
//     EmployeeID INT,
//     FOREIGN KEY (EmployeeID) REFERENCES Employees(EmployeeID)
// );
// 3. Unique Key
// Ensures all values in a column are unique (like a Primary Key).
// Can contain NULL values.
// Example:
// sql
// Copy
// Edit
// CREATE TABLE Users (
//     UserID INT PRIMARY KEY,
//     Email VARCHAR(100) UNIQUE
// );



// //
// SQL Constraints: NOT NULL, UNIQUE, and PRIMARY KEY
// SQL constraints enforce rules on table columns to maintain data integrity. Here’s how NOT NULL, UNIQUE, and PRIMARY KEY work:

// 1. NOT NULL Constraint
// Ensures that a column cannot have NULL values.
// Every row must have a value in this column.
// Example:
// sql
// Copy
// Edit
// CREATE TABLE Employees (
//     EmployeeID INT NOT NULL,
//     Name VARCHAR(100) NOT NULL
// );

// 2. UNIQUE Constraint
// Ensures that all values in a column are distinct (no duplicates).
// Allows NULL values (except in some databases like MySQL with strict mode).
// Example:
// sql
// Copy
// Edit
// CREATE TABLE Users (
//     UserID INT PRIMARY KEY,
//     Email VARCHAR(100) UNIQUE
// );
// You can also define multiple UNIQUE constraints in a table.

// 3. PRIMARY KEY Constraint
// A combination of NOT NULL and UNIQUE.
// Uniquely identifies each row in a table.
// A table can have only one PRIMARY KEY.
// Example:
// sql
// Copy
// Edit

// CREATE TABLE Orders (
//     OrderID INT PRIMARY KEY,
//     OrderDate DATE NOT NULL
// );

// CREATE TABLE Orders (
//     id INT ,
//     student varchar
// );

// also // CREATE TABLE Orders (
//      PRIMARY KEY(id, student),
//
// );     it means that id or student can be dublicate but there pair can not be




// FOREIGN KEY Constraint in SQL
// A FOREIGN KEY is a constraint that establishes a relationship between two tables. It ensures referential integrity by linking a column in one table to the PRIMARY KEY of another table.

// Key Features of FOREIGN KEY:
// Ensures data consistency by preventing actions that would break relationships.
// The foreign key column must refer to a primary key in another table.
// If a referenced record in the parent table is deleted/updated, behavior is controlled by ON DELETE and ON UPDATE actions.
// 1. Creating a FOREIGN KEY
// sql
// Copy
// Edit
// CREATE TABLE Customers (
//     CustomerID INT PRIMARY KEY,
//     Name VARCHAR(100) NOT NULL
// );

// CREATE TABLE Orders (
//     OrderID INT PRIMARY KEY,
//     CustomerID INT,
//     OrderDate DATE,
//     FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
// );
// 🔹 Here, CustomerID in the Orders table is a foreign key referencing CustomerID in Customers.

// 2. Adding a FOREIGN KEY to an Existing Table
// sql
// Copy
// Edit
// ALTER TABLE Orders
// ADD CONSTRAINT fk_customer FOREIGN KEY (CustomerID)
// REFERENCES Customers(CustomerID);

//3.DEFAULT Constraint in SQL
// The DEFAULT constraint in SQL is used to provide a default value for a column when no value is specified during an INSERT operation.

// 1. Creating a Table with DEFAULT Constraint
// sql
// Copy
// Edit
// CREATE TABLE Employees (
//     EmpID INT PRIMARY KEY,
//     Name VARCHAR(100) NOT NULL,
//     Department VARCHAR(50) DEFAULT 'General',
//     Salary DECIMAL(10,2) DEFAULT 30000.00,
//     JoiningDate DATE DEFAULT CURRENT_DATE
// );
// 🔹 If a new employee is inserted without specifying Department, Salary, or JoiningDate, they will get the default values.


// Key Takeaways
// ✅ Provides default values if no value is inserted.
// ✅ Can be applied to any data type.
// ✅ Supports functions like CURRENT_DATE, NOW(), UUID() in some databases.
// ✅ Can be added or removed using ALTER TABLE.




// CHECK Constraint in SQL
// The CHECK constraint in SQL is used to ensure that the values entered into a column meet specific conditions before being inserted or updated.

// 1. Creating a Table with CHECK Constraint
// sql
// Copy
// Edit
// CREATE TABLE Employees (
//     EmpID INT PRIMARY KEY,
//     Name VARCHAR(100) NOT NULL,
//     Age INT CHECK (Age >= 18),
//     Salary DECIMAL(10,2) CHECK (Salary > 10000)
// );
// 🔹 This ensures:

// Age must be 18 or older
// Salary must be greater than 10,000
// 2. Using Named CHECK Constraints
// sql
// Copy
// Edit
// CREATE TABLE Products (
//     ProductID INT PRIMARY KEY,
//     ProductName VARCHAR(100) NOT NULL,
//     Price DECIMAL(10,2),
//     CONSTRAINT chk_price CHECK (Price > 0)
// );
// 🔹 Here, chk_price ensures Price is greater than 0.

// 3. Adding a CHECK Constraint to an Existing Table
// sql
// Copy
// Edit
// ALTER TABLE Employees
// ADD CONSTRAINT chk_salary CHECK (Salary >= 20000);
// 4. Removing a CHECK Constraint
// sql
// Copy
// Edit
// ALTER TABLE Employees
// DROP CONSTRAINT chk_salary;



// Most Commonly Used SELECT Commands in SQL
// The SELECT statement is used to retrieve data from a database. Below are the most commonly used queries:

// 1. Selecting All Columns
// sql
// Copy
// Edit
// SELECT * FROM Employees;
// 🔹 Retrieves all columns from the Employees table.

// 2. Selecting Specific Columns
// sql
// Copy
// Edit
// SELECT Name, Age, Salary FROM Employees;
// 🔹 Fetches only Name, Age, and Salary columns.

// 3. Using WHERE Clause (Filtering Data)
// sql
// Copy
// Edit
// SELECT * FROM Employees WHERE Age > 30;
// 🔹 Returns employees older than 30.

// sql
// Copy
// Edit
// SELECT * FROM Employees WHERE Department = 'HR' AND Salary > 50000;
// 🔹 Fetches employees from HR department with Salary > 50,000.

// 4. Sorting Data (ORDER BY)
// sql
// Copy
// Edit
// SELECT * FROM Employees ORDER BY Salary DESC;
// 🔹 Retrieves all employees sorted by Salary in descending order.

// sql
// Copy
// Edit
// SELECT Name, Age FROM Employees ORDER BY Age ASC;
// 🔹 Sorts employees by Age in ascending order.

// 5. Limiting Records (LIMIT or TOP)
// MySQL & PostgreSQL
// sql
// Copy
// Edit
// SELECT * FROM Employees LIMIT 5;
// 🔹 Retrieves the first 5 records.

// SQL Server
// sql
// Copy
// Edit
// SELECT TOP 5 * FROM Employees;
// 🔹 Works similarly to LIMIT in SQL Server.

// 6. Finding Unique Values (DISTINCT)
// sql
// Copy
// Edit
// SELECT DISTINCT Department FROM Employees;
// 🔹 Returns unique department names.

// 7. Using Aggregate Functions
// sql
// Copy
// Edit
// SELECT COUNT(*) FROM Employees;
// 🔹 Counts total number of employees.

// sql
// Copy
// Edit
// SELECT AVG(Salary) FROM Employees;
// 🔹 Finds the average salary.

// sql
// Copy
// Edit
// SELECT MAX(Salary), MIN(Salary) FROM Employees;
// 🔹 Retrieves the highest and lowest salary.

// 8. Grouping Data (GROUP BY)
// sql
// Copy
// Edit
// SELECT Department, COUNT(*) FROM Employees GROUP BY Department;
// 🔹 Counts employees in each department.

// sql
// Copy
// Edit
// SELECT Department, AVG(Salary) FROM Employees GROUP BY Department;
// 🔹 Finds average salary per department.

// 9. Filtering Grouped Data (HAVING)
// sql
// Copy
// Edit
// SELECT Department, AVG(Salary)
// FROM Employees
// GROUP BY Department
// HAVING AVG(Salary) > 60000;
// 🔹 Retrieves departments where the average salary is above 60,000.

// 10. Joining Tables (INNER JOIN)
// sql
// Copy
// Edit
// SELECT Employees.Name, Departments.DepartmentName
// FROM Employees
// INNER JOIN Departments ON Employees.DepartmentID = Departments.DepartmentID;
// 🔹 Fetches employee names with their department names.

// 11. Subqueries (SELECT inside SELECT)
// sql
// Copy
// Edit
// SELECT Name, Salary FROM Employees
// WHERE Salary > (SELECT AVG(Salary) FROM Employees);
// 🔹 Retrieves employees earning above the average salary.

// 12. Using IN and BETWEEN
// sql
// Copy
// Edit
// SELECT * FROM Employees WHERE Department IN ('HR', 'IT');
// 🔹 Fetches employees from HR or IT departments.

// sql
// Copy
// Edit
// SELECT * FROM Employees WHERE Salary BETWEEN 40000 AND 80000;
// 🔹 Retrieves employees earning between 40,000 and 80,000.

// 13. Using LIKE for Pattern Matching
// sql
// Copy
// Edit
// SELECT * FROM Employees WHERE Name LIKE 'J%';
// 🔹 Retrieves employees whose name starts with "J".

// sql
// Copy
// Edit
// SELECT * FROM Employees WHERE Name LIKE '%son';
// 🔹 Fetches employees whose name ends with "son".

// 14. Using CASE (Conditional Selection)
// sql
// Copy
// Edit
// SELECT Name, Salary,
//        CASE
//            WHEN Salary > 80000 THEN 'High Salary'
//            WHEN Salary BETWEEN 40000 AND 80000 THEN 'Medium Salary'
//            ELSE 'Low Salary'
//        END AS SalaryCategory
// FROM Employees;
// 🔹 Categorizes employees based on salary range.

// 15. Using EXISTS (Checking Data Existence)
// sql
// Copy
// Edit
// SELECT Name FROM Employees WHERE EXISTS
//     (SELECT 1 FROM Departments WHERE Employees.DepartmentID = Departments.DepartmentID);
// 🔹 Checks if an employee is assigned to a department.




// In SQL, operators are used to perform operations on data. Here are some of the most commonly used operators in SQL queries:

// 1. Arithmetic Operators
// These operators are used for mathematical operations.

// + (Addition)
// - (Subtraction)
// * (Multiplication)
// / (Division)
// % (Modulus)
// Example:

// sql
// Copy
// Edit
// SELECT price * quantity AS total_cost FROM orders;
// 2. Comparison Operators
// These operators are used to compare two values.

// = (Equal to)
// != or <> (Not equal to)
// > (Greater than)
// < (Less than)
// >= (Greater than or equal to)
// <= (Less than or equal to)
// Example:

// sql
// Copy
// Edit
// SELECT * FROM employees WHERE age >= 30;
// 3. Logical Operators
// These are used to combine multiple conditions in the WHERE clause.

// AND (Returns true if both conditions are true)
// OR (Returns true if at least one condition is true)
// NOT (Reverses the result of a condition)
// Example:

// sql
// Copy
// Edit
// SELECT * FROM customers WHERE country = 'USA' AND status = 'Active';
// 4. BETWEEN Operator
// Used to filter the result set within a certain range.

// BETWEEN value1 AND value2
// Example:

// sql
// Copy
// Edit
// SELECT * FROM products WHERE price BETWEEN 100 AND 500;
// 5. IN Operator
// Used to filter the result set based on a list of values.

// IN (value1, value2, ...)
// Example:

// sql
// Copy
// Edit
// SELECT * FROM orders WHERE status IN ('Shipped', 'Delivered');
// 6. LIKE Operator
// Used to search for a specified pattern in a column.

// LIKE (for pattern matching)
// % (Represents zero or more characters)
// _ (Represents a single character)
// Example:

// sql
// Copy
// Edit
// SELECT * FROM employees WHERE name LIKE 'J%';
// 7. IS NULL / IS NOT NULL Operators
// Used to check for NULL values.

// IS NULL (Checks if a value is NULL)
// IS NOT NULL (Checks if a value is not NULL)
// Example:

// sql
// Copy
// Edit
// SELECT * FROM products WHERE discount IS NULL;
// 8. EXISTS Operator
// Used to check the existence of a subquery result.

// EXISTS (Returns true if the subquery returns any records)
// Example:

// sql
// Copy
// Edit
// SELECT * FROM employees WHERE EXISTS (SELECT * FROM departments WHERE department_id = employees.department_id);
// 9. ANY / ALL Operators
// Used to compare a value to a set of values returned by a subquery.

// ANY (Compares to any value returned by the subquery)
// ALL (Compares to all values returned by the subquery)
// Example:

// sql
// Copy
// Edit
// SELECT * FROM orders WHERE total_amount > ALL (SELECT amount FROM discounts);
// 10. DISTINCT Operator
// Used to return only distinct (different) values.

// Example:

// sql
// Copy
// Edit
// SELECT DISTINCT country FROM customers;