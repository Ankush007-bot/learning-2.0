
import './App.css';
import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { v4 as uuidv4 } from "uuid";
// set the proxy in package.json "proxy":"http://127.0.0.1:5000",
function App() {

  const [loading, setLoading] = useState(false);
  const [orderAmount, setOrderAmount] = useState(0);
  const [orders, setOrders] = useState([]);

  const [link , setLink]= useState()

  // function to fetching orders from backend
  async function fetchOrders() {
    const { data } = await axios.get('/list-orders');
    setOrders(data);
  }

  //by using empty array fetchOrders will only run one time after rendering the component

  useEffect(() => {
    fetchOrders();
  }, []);


  function loadRazorpay() {
    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.onerror = () => {
      alert('Razorpay SDK failed to load. Are you online?');
    };
    script.onload = async () => {
      try {
        setLoading(true);
        const result = await axios.post('/create-order', {
          amount: orderAmount + '00',
        });

        const { amount, id: order_id, currency } = result.data;
       
        //const { data: { key: razorpayKey }, } = await axios.get('/get-razorpay-key');     
        //respnse is {"key":"rzp_test_nIBwSlZ3nod8MN"}
        const razorpayKey = await axios.get('/get-razorpay-key');

        const options = {
          key: razorpayKey,
          amount: amount.toString(),
          currency: currency,
          name: 'example name',
          description: 'example transaction',
          order_id: order_id,
          handler: async function (response) {    // handler happens when payment is successfull
            const result = await axios.post('/pay-order', {
              amount: amount,
              razorpayPaymentId: response.razorpay_payment_id,
              razorpayOrderId: response.razorpay_order_id,
              razorpaySignature: response.razorpay_signature,
            });
            alert(result.data.msg);
            
            const result2 = await axios.post('/api/payment/verify', {
              amount: amount,
              razorpayPaymentId: response.razorpay_payment_id,
              razorpayOrderId: response.razorpay_order_id,
              razorpaySignature: response.razorpay_signature,
            });
            alert(result2.data.msg);
            fetchOrders();
          },
          prefill: {
            name: 'example name',
            email: 'email@example.com',
            contact: '111111',
          },
          notes: {
            address: 'example address',
          },
          theme: {
            color: '#80c0f0',
          },
        };

        setLoading(false);

        const paymentObject = new window.Razorpay(options);
        
        paymentObject.open();
      } catch (err) {
        alert(err);
        setLoading(false);
      }
    };
    document.body.appendChild(script);
  }

const createPaymentLink = async ()=>{

const link= await axios.post("/createPaymentLink").then((response)=>{
  // console.log(response.data.paymentlink
  //   )
  return response.data.paymentlink
}).catch((error)=>{console.log(error)})

//console.log(link,"link")

setLink(link)
}
  

  return (
    <div className="App">
      <h1> Razor-Pay Payment_Gateway(Info-Axon)</h1>
      <hr />
      <div>
        <h2> Pay Order</h2>
        <label>
          Amount:{' '}
          <input
            placeholder="INR"
            type="number"
            value={orderAmount}
            onChange={(e) => setOrderAmount(e.target.value)}
          ></input>
        </label>

        <button disabled={loading} onClick={loadRazorpay}>
          payment now
        </button>
        {loading && <div>Loading...</div>}
      </div>
      <div className="list-orders">
        <h2>List Orders</h2>
        <table>
          <thead>
            <tr>
              <th>ID</th>
              <th>AMOUNT</th>
              <th>ISPAID</th>
              <th>RAZORPAY</th>
            </tr>
          </thead>
          <tbody>
            {orders.map((x) => (
              <tr key={x._id}>
                <td>{x._id}</td>
                <td>{x.amount / 100}</td>
                <td>{x.isPaid ? 'YES' : 'NO'}</td>
                <td>{x.razorpay.paymentId}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div>   <button  onClick={createPaymentLink}>
          create payment link
        </button>

      <a href={link}> {link}</a>
       
        
        </div>

      
    </div>
  );
}

export default App;
