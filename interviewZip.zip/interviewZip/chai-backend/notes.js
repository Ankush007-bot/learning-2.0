//1. firsst we learnt how to connct from mngo db code is in folder db
//2 . wrote code mongo db connection with node js in index.js
//3. set our app and make server on port created routes in app.js
//4. wrote the code of routes in routes folder then import it  in file app.js
//5 . Then we created the  models  which is the model(structure) of the doument which is called schema
//6  . then we learnt about hooks of models
//7.  Then we leant about refresh token
//8.  Then we wrote the controllers
      // In this w learthow to use multer abd cloudnery
 //9. Then we learnt about refresh tokens

 //10 Then we learnt about how we can use  middleware
