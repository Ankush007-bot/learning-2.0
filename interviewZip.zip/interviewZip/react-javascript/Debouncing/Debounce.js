import React, { useState, useCallback } from "react";
import debounce from "lodash/debounce";

const DebouncedInput = () => {
  const [inputValue, setInputValue] = useState(""); // Immediate value
  const [debouncedValue, setDebouncedValue] = useState(""); // Debounced value

  // Debounced function to update the state
  const updateDebouncedValue = useCallback(
    debounce((value) => {
      setDebouncedValue(value); // Update the debounced state
    }, 300),
    [] // Ensure the debounce function is stable
  );

  // Handle input changes
  const handleChange = (e) => {
    const value = e.target.value;
    setInputValue(value); // Update the immediate value
    updateDebouncedValue(value); // Call the debounced updater
  };

  return (
    <div>
      <input
        type="text"
        placeholder="Type something..."
        value={inputValue}
        onChange={handleChange}
      />
      <p>Immediate Value: {inputValue}</p>
      <p>Debounced Value: {debouncedValue}</p>
    </div>
  );
};

export default DebouncedInput;